'''
Created on 18 apr 2013

@author: Einar
'''
from collections import defaultdict
from naoqi import ALProxy
import math

distanceUnit = 0.5

#import operator


if __name__ == '__main__':
    pass

    motion = ALProxy("ALMotion", "localhost", 9559)
    sonarProxy = ALProxy("ALSonar", "localhost", 9559)
    sonarProxy.subscribe("NaoMaze")
    memoryProxy = ALProxy("ALMemory", "localhost", 9559)
    
    
    
    pNames = "Body"
    pStiffnessLists = 1.0
    pTimeLists = 1.0
    motion.stiffnessInterpolation(pNames, pStiffnessLists, pTimeLists)

    motion.moveInit()


    
    matrixMap = defaultdict(int)
    mazeBlueprint = defaultdict(int)

    mazeBlueprint[0, 0]=1;
    mazeBlueprint[1, 0]=1;
    mazeBlueprint[2, 0]=1;

    mazeBlueprint[1, 2]=1;
    mazeBlueprint[1, 4]=1;
    
    mazeBlueprint[2, 1]=1;
    mazeBlueprint[2, 2]=1;
    mazeBlueprint[2, 3]=1;
    mazeBlueprint[2, 4]=1;
    
    mazeBlueprint[3, 4]=1;
    mazeBlueprint[4, 4]=1;
    mazeBlueprint[5, 4]=1;
    mazeBlueprint[5, 5]=100;
    
    x=0
    y=0
    goal = False
    testDirection = 1
    direction = 0;
    
    turnProbability = defaultdict(str)
    turnProbability["left"]=1
    turnProbability["right"]=1
    turnProbability["up"]=1
    turnProbability["down"]=1
    
    mode = 0 # mode 0 = walking in a straight line of previously unvisited areas  
    while (not goal):
        print(memoryProxy.getData("Device/SubDeviceList/US/Left/Sensor/Value"))
        print (memoryProxy.getData("Device/SubDeviceList/US/Right/Sensor/Value"))
        if mode == 0:   # Explore a straight line if nothing special happens
            if testDirection == 0:   
            #If statement checks if there is one free square at this block in the testDirection we are heading
                if not mazeBlueprint[x,y+1]==0 and not matrixMap[x,y+1]==2 :
                    #print("Free space up. Walks up")
                    print ("Takes one step up from " + str(x)  + ", " + str(y))
                    y+=1
                    motion.walkTo(distanceUnit,0,0)
                    matrixMap[x,y]=2
            # If not rotate 90 degrees clockwise
                else: mode = 1
            
            if testDirection == 1:
                #If statement checks if there is one free square at this block
                if not mazeBlueprint[x+1,y]==0 and not matrixMap[x+1,y]==2:
                    #print("Free right. Walks right")
                    print ("Takes one step right from " + str(x)  + ", " + str(y))
                    x+=1
                    motion.walkTo(distanceUnit,0,0)
                    matrixMap[x,y]=2
                else: mode = 1
            
            if testDirection == 2:
                if not mazeBlueprint[x,y-1]==0 and not matrixMap[x,y-1]==2:
                    #print("Free space down. Walks down")
                    print ("Takes one step down from " + str(x)  + ", " + str(y))
                    y-=1
                    motion.walkTo(distanceUnit,0,0)
                    matrixMap[x,y]=2
                else: mode = 1

            if testDirection == 3:
                if not mazeBlueprint[x-1,y]==0 and not matrixMap[x-1,y]==2:
                    #print("Free space left. Walks left")
                    print ("Takes one step up from " + str(x)  + ", " + str(y))
                    x-=1
                    motion.walkTo(distanceUnit,0,0)
                    matrixMap[x,y]=2
                else: mode = 1
                
        # All was not well. Blocked in preferred direction. Must decide what to do next. Enter decision mode.
        if mode == 1:
            '''
            Following might seem a bit unecessary but if we want to implement several other
            parameters this might be a good place to fine tune the likelyhood of Nao turning 
            one direction instead of another.
            '''
            #Direction 4 means undecided
            direction = 4
            
            # First check if there is any of the directions that are already visited on the map.
            if matrixMap[x-1,y]==2: turnProbability["left"] *= 0.25
            if matrixMap[x+1,y]==2: turnProbability["right"] *= 0.25
            if matrixMap[x,y-1]==2: turnProbability["down"] *= 0.25
            if matrixMap[x,y+1]==2: turnProbability["up"] *= 0.25

            # The check if there are any walls. It is then impassable and should be set to zero.
            if mazeBlueprint[x-1,y]==0: turnProbability["left"] *= 0
            if mazeBlueprint[x+1,y]==0: turnProbability["right"] *= 0
            if mazeBlueprint[x,y-1]==0: turnProbability["down"] *= 0
            if mazeBlueprint[x,y+1]==0: turnProbability["up"] *= 0

            # The check if there are any walls. If not it is passable and should be posible to visit.
            if mazeBlueprint[x-1,y]==1: turnProbability["left"] *= 1
            if mazeBlueprint[x+1,y]==1: turnProbability["right"] *= 1
            if mazeBlueprint[x,y-1]==1: turnProbability["down"] *= 1
            if mazeBlueprint[x,y+1]==1: turnProbability["up"] *= 1
            
            
            print ("turns " + max(turnProbability.iterkeys(), key = (lambda key: turnProbability[key])))
            
            if max(turnProbability.iterkeys(), key = (lambda key: turnProbability[key])) == "up":
                print(turnProbability)
                if testDirection==1: motion.walkTo(0,0,math.pi/2)        
                if testDirection==2: motion.walkTo(0,0,math.pi)
                if testDirection==3: motion.walkTo(0,0,-math.pi/2)
                
                testDirection=0
                
            if max(turnProbability.iterkeys(), key = (lambda key: turnProbability[key])) == "down":
                print(turnProbability)
                if testDirection==0: motion.walkTo(0,0,math.pi)        
                if testDirection==1: motion.walkTo(0,0,-math.pi/2)
                if testDirection==3: motion.walkTo(0,0,math.pi/2)
                
                testDirection=2
                
            if max(turnProbability.iterkeys(), key = (lambda key: turnProbability[key])) == "left":
                print(turnProbability)
                if testDirection==0: motion.walkTo(0,0,math.pi/2)        
                if testDirection==1: motion.walkTo(0,0,math.pi)
                if testDirection==2: motion.walkTo(0,0,-math.pi/2)
                
                testDirection=3
                
            if max(turnProbability.iterkeys(), key = (lambda key: turnProbability[key])) == "right":
                print(turnProbability)
                if testDirection==0: motion.walkTo(0,0,-math.pi/2)        
                if testDirection==2: motion.walkTo(0,0,math.pi/2)
                if testDirection==3: motion.walkTo(0,0,math.pi)
                
                testDirection=1
            
            # Reset the probabilities to 1 for all directions.
            turnProbability["left"] = 1
            turnProbability["right"] = 1
            turnProbability["down"] = 1
            turnProbability["up"] = 1
            
            mode = 0 # Direction selected. Return to exploration
            
            #foo=input('Please enter a value:')
            
        if mazeBlueprint[x,y]==100: goal = True