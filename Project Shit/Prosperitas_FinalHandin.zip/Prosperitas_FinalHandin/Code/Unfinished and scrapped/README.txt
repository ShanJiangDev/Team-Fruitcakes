README 
********************************
Unfinished and scrapped parts
********************************

The files in this directory are parts of either unfinished or iceboxed parts of the development. Content are mainly experimental and in no way finished evn though parts are funcitonal. 
The main reasons to include this in the hand in is to pass on what we have done to other students and to show some of our efforts that for various reasons not have been included in the main project.

distance.py & NaoMaze.py
These are experiements of navigating Nao through a maze of boxes. In NaoMaze.py the basic concept of letting Nao navigate according to a map and using a set step length to jugde the distance travelled is tested. In distance.py instead of a map Nao tries to navigate using a combination of a map and sensor input. As describe in the function list both are failing because of unconsistencies in sonar reading, step length and actual radians turned. Not even using an average of 100 sonar readings the distance is measured properly in other than best case scenarios.

sort.py
The start or logics for a function wher Nao describes sorting algorithms. They are tested to work in an emulator and the robot is describing it in a proper manner. Still vioce input is not implemented and the larger function they were to be incorporated to was iceboxed.

WritingStuFF.crg
The Choregraphe project where we tried to modify the movement of naos joints to make the robot write its name. It was scrapped because of limitations in joint movement.

