'''
Created on 30 apr 2013

@author: einar
'''
from naoqi import ALProxy
from Tkinter import *


def merge(left, right):
    result = []
    i ,j = 0, 0
    while i < len(left) and j < len(right):
        if left[i] <= right[j]:
            result.append(left[i])
            i += 1
        else:
            result.append(right[j])
            j += 1

    result += left[i:]
    result += right[j:]
    return result
 
 
def mSort(lst, tts, level):
    if len(lst) <= 1:
        return lst
    middle = int( len(lst) / 2 )
    say = "splitting list of numbers in the middle we are currently at recursion level " + str(level)
    print(say)
    tts.say(say)
    
    say ="from recursion level " + str(level) + " passing the numbers " + str(lst[:middle]) + " to left recursive sort"
    print(say)
    tts.say(say)
    left = mSort(lst[:middle],tts, level+1)
    
    say ="from recursion level " + str(level) + " passing the numbers " + str(lst[middle:]) + " to left recursive sort"
    print(say)
    tts.say(say)
    right = mSort(lst[middle:],tts, level+1)
    

    say ="merging and returning sorted sublists " +str(left) + " and " + str(right) + "from recursion level " + str(level)
    print(say)
    tts.say(say)

    ret = merge(left, right)

    
    return ret

 
if __name__ == "__main__":


    inArray=[43,21,12]


    root = Tk()

    var = StringVar()
    var.set("Hey!? How are you doing?")
    label = Message( root, textvariable=var)
    label.pack()

    var.set("TNT")
    label.pack()


    tts = ALProxy("ALTextToSpeech", "localhost", 9559)

    sent = "Hello world"

    #tts.say("You said" + str(inArray))
    end=len(inArray)-1
    while (end!=-1):
        swapped=-1
        say = "The numbers are: " + str(inArray)
        print (say)
        tts.say(say)
            
        for i in range(0,end):
            if inArray[i]>inArray[i+1]:
                say = str(inArray[i])+" is larger than " + str(inArray[i+1]) + " so they are swapping place"
                print (say)
                tts.say(say)
                temp=inArray[i]
                inArray[i]=inArray[i+1]
                inArray[i+1]=temp
                swapped=i
            else: 
                say = str(inArray[i])+" is not larger than " + str(inArray[i+1]) + " so I wont do anything"
                print (say)
                tts.say(say)
        
        end=swapped
        if end == -1: 
                say = "That was hard but now the numbers are sorted " + str(inArray)
                print (say)
                tts.say(say)
        else: 
                say = "I changed the place of some numbers. I better check that all are in order"
                print (say)
                tts.say(say)
    mSort(inArray,tts,1)             
                
    